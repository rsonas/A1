/*
    config.js
    Aislinn Richardson 
    301146892
    09/14/23
*/

module.exports = require('./env/' + process.env.NODE_ENV + '.js');